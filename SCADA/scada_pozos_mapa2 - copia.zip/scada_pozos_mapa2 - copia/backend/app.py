import time, math
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from starlette.staticfiles import StaticFiles

app = FastAPI(title="SCADA Pozos — Mapa")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

ROOT = Path(__file__).resolve().parent.parent
FRONT = ROOT / "frontend"
INDEX = FRONT / "index.html"
app.mount("/static", StaticFiles(directory=str(FRONT)), name="static")

start = time.time()
@app.get("/")
def home(): return FileResponse(str(INDEX))

@app.get("/estado")
def estado():
    t = time.time()-start
    return {
      "pozo1":{"nivel":(math.sin(t/5.0)+1)/2,"bomba":int((t%10)>5)},
      "pozo2":{"nivel":(math.cos(t/6.5)+1)/2,"bomba":int((t%8)>4)},
      "pozo3":{"nivel":0.55+0.35*math.sin(t/9.0+1.7),"bomba":int((t%12)>6)},
    }